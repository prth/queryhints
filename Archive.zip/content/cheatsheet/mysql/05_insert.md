---
slug: mysql-insert
order:
  list: 5
template: cheatsheet
title: Insert
dbs:
  - mysql
content: |
  INSERT INTO table1 (field1, field2) VALUES ('value1', 'value2');
---
