---
slug: mysql-delete
order:
  list: 7
template: cheatsheet
title: Delete
dbs:
  - mysql
content: |
  DELETE FROM table1 WHERE field1='value1';
---
