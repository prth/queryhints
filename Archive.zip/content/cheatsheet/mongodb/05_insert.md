---
slug: mongodb-insert
order:
  list: 5
template: cheatsheet
title: Insert
dbs:
  - mongodb
content: |
  db.collection.save({ field1: 'value1', field2: 'value2' });
---
