---
slug: mongodb-delete
order:
  list: 7
template: cheatsheet
title: Delete
dbs:
  - mongodb
content: |
  db.collection.remove({ field1: 'value1' });
---
