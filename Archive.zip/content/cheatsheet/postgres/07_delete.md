---
slug: postgres-delete
order:
  list: 7
template: cheatsheet
title: Delete
dbs:
  - postgres
content: |
  DELETE FROM table1 WHERE field1='value1';
---
