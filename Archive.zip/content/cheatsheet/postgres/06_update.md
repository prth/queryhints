---
slug: postgres-update
order:
  list: 6
template: cheatsheet
title: Update
dbs:
  - postgres
content: |
  UPDATE table SET field1='new_value1' WHERE field2='value2';
---
