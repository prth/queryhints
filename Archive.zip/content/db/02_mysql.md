---
order:
  list: 2
template: db
slug: mysql
title: MySQL
tags:
  - select
  - limit
queryViewerLanguage: sql
---
