---
order:
  list: 3
template: db
slug: postgres
title: PostgreSQL
tags:
  - select
  - limit
queryViewerLanguage: sql
---
